// Import required module
const readline = require('readline');

const Solution = () => {
  // Write your code here

  const interface = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  interface.question("enter the first number: ", (num1) => {
    interface.question("eneter the second number: ", (num2) => {

      const number1 = Number(num1);
      const number2 = Number(num2);

      // Determine and display the maximum number
      if (number1 > number2) {
        console.log("The maximum of the two numbers is: " + number1);
      } else {
        console.log("The maximum of the two numbers is: " + number2);
      }

      // Close the readline interface
      interface.close();
    })
  });
};

Solution();
module.exports = Solution;
